// Shimmerable.swift
// Copyright © RoadMap. All rights reserved.

import Foundation

protocol Shimmerable {}

extension Shimmerable {}

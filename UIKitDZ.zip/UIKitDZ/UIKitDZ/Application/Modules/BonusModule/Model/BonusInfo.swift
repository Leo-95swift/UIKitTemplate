// BonusInfo.swift
// Copyright © RoadMap. All rights reserved.

/// Данные об экране с бонусами
struct BonusInfo {
    /// Количество бонусов
    var bonusesCount: String
}

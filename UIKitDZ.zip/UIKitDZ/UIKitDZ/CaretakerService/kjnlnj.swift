// kjnlnj.swift
// Copyright © RoadMap. All rights reserved.

import Foundation

let usersData: [UserData] = [
    UserData(
        userName: "aa",
        login: "login1",
        password: "password",
        imageName: "akjiowj"
    ),
    UserData(
        userName: "aa",
        login: "login2",
        password: "password",
        imageName: "akjiowj"
    ),
    UserData(
        userName: "aa",
        login: "login3",
        password: "password",
        imageName: "akjiowj"
    ),
    UserData(
        userName: "aa",
        login: "login",
        password: "password",
        imageName: "akjiowj"
    ),
    UserData(
        userName: "aa",
        login: "login",
        password: "password",
        imageName: "akjiowj"
    )
]

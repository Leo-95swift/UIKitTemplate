// Login.swift
// Copyright © RoadMap. All rights reserved.

import Foundation

/// kjbkj
struct Login {
    static var login = ""
}

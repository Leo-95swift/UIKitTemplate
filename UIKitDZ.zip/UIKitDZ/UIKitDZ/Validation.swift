// Validation.swift
// Copyright © RoadMap. All rights reserved.

import Foundation

/// hbhbvh
struct Validation {
    let email: String
    let password: String
}

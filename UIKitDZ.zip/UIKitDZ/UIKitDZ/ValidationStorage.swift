// ValidationStorage.swift
// Copyright © RoadMap. All rights reserved.

import Foundation

/// jnjnjnj
struct ValidationStorage {
    let validations: [Validation] = [
        Validation(
            email: "asdf@mail.ru",
            password: "123456"
        ),
        Validation(
            email: "zxcv@mail.ru",
            password: "456789"
        ),
        Validation(
            email: "qwerty@mail.ru",
            password: "987654321"
        )
    ]
}
